//#define GVCOptionRequired 0
//90 second before restart in loop count is 3
#define WIFIRETRYAFTERCONNECTIONLIMIT 75 // As proposed by NB 20 How many minutes 30 minutes
// 75 seconds for one loop
#define MAXWIFILOOPCOUNT 25 // As proposed by NB 10  // how many minutes? 30 minutes
  // added on 100525
#define MAXSIPNUMBER 3
#define MAXMIPNUMBER 3

#define MAX_NUMBER_OF_LIGHTS 8


#define QOS 1
#define BroadcastTopic "GVC/KP/BROADCAST"

typedef enum LED_STATES{
    STANDBY_LED,
    SEARCH_FOR_WIFI,
    WAIT4ESPTOUCH,
    SEARCH_FOR_ESPTOUCH,
    SEARCH_FOR_WIFI1,
    SEARCH_FOR_WIFI2,
    SEARCH_FOR_WIFI3,
    WIFI_FOUND_NO_INTERNET,
    WIFI_AND_INTERNET_NO_SERVER,
    EVERYTHING_OK_LED,
    OTA_IN_PROGRESS,
    WAITING_FOR_RESTART,
    INCOMING_PULSE_DETECTED,
    MQTT_DISCONNECTED,
    MQTT_PUBLISH_FAILED,
    MQTT_HBT_NOT_RECEIVED
}Led_State_t;

typedef enum TCPIP_SOCKET_STATE{
    SOCKET_CONNECTED,
    SOCKET_DISCONNECTED
}TCPIP_Socket_State;

#define MAX_HTTP_RECV_BUFFER 1024

#define LED_ACTIVE_HIGH
#define ESP_MAXIMUM_RETRY       0

#define ESP_RETRY_GAP           2000
#define Production          1
#define NVS_INH_KEY           "INH"
#define NVS_SSID_1_KEY        "SSID1"
#define NVS_PASS_1_KEY        "PASS1"
#define NVS_SSID_2_KEY        "SSID2"
#define NVS_PASS_2_KEY        "PASS2"
#define NVS_SSID_3_KEY        "SSID3"
#define NVS_PASS_3_KEY        "PASS3"

#define NVS_SERVER_IP_KEY     "SERVER"
#define NVS_SERVER_PORT_KEY   "PORT"
#define NVS_SERVER_PORT_KEY_JUMPER "JUMPERPORT" 
#define NVS_OTA_URL_KEY   "OTA_URL"
#define NVS_CA_KEY          "CA"
#define NVS_CASHTOTAL_KEY   "CASHTOTAL"
#define NVS_VENDTOTAL_KEY   "VENDTOTAL"
#define NVS_CASH1_KEY   "CASH1"
#define NVS_CASH2_KEY   "CASH2"
#define NVS_CASH3_KEY   "CASH3"
#define NVS_CASH4_KEY   "CASH4"
#define NVS_CASH5_KEY   "CASH5"
#define NVS_CASH6_KEY   "CASH6"
#define NVS_CASH7_KEY   "CASH7"

#define DEFAULT_SSID1  "GVCSYS1"
#define DEFAULT_PASS1  "GVC3065V"
#define DEFAULT_SSID2  "GVCSYS2"
#define DEFAULT_PASS2  "GVC3065V"
#define DEFAULT_SSID3  "GVCSYS3"
#define DEFAULT_PASS3  "GVC3065V"
#define DEFAULT_TIMESTAMP "1733663095"

#define NVS_UNIX_TS   "UNIX_TS"

#define NVS_QR_STRING   "QR_STRING"

#define NVS_SIP_USERNAME     "USERNAME_SIP"
#define NVS_SIP_DATETIME   "DATETIME_SIP"

  // added on 100525
#define NVS_MIP_USERNAME     "USERNAME_MIP"
#define NVS_MIP_DATETIME   "DATETIME_MIP"

#define NVS_CA_USERNAME     "USERNAME_CA"
#define NVS_CA_DATETIME   "DATETIME_CA"

#define NVS_CC_USERNAME     "USERNAME_CC"
#define NVS_CC_DATETIME   "DATETIME_CC"

#define NVS_URL_USERNAME     "USERNAME_URL"
#define NVS_URL_DATETIME   "DATETIME_URL"

#define NVS_FOTA_USERNAME     "USERNAME_FOTA"
#define NVS_FOTA_DATETIME   "DATETIME_FOTA"

#define NVS_RST_USERNAME     "USERNAME_RST"
#define NVS_RST_DATETIME   "DATETIME_RST"

#define NVS_SN_USERNAME     "USERNAME_SN"
#define NVS_SN_DATETIME   "DATETIME_SN"

#define NVS_SS_USERNAME     "USERNAME_SS"
#define NVS_SS_DATETIME   "DATETIME_SS"

#define NVS_SL_USERNAME     "USERNAME_SL"
#define NVS_SL_DATETIME   "DATETIME_SL"

#define NVS_PW_USERNAME     "USERNAME_PW"
#define NVS_PW_DATETIME   "DATETIME_PW"

#define NVS_SS1_USERNAME     "USERNAME_SS1"
#define NVS_SS1_DATETIME   "DATETIME_SS1"

#define NVS_PW1_USERNAME     "USERNAME_PW1"
#define NVS_PW1_DATETIME   "DATETIME_PW1"

#define NVS_SS2_USERNAME     "USERNAME_SS2"
#define NVS_SS2_DATETIME   "DATETIME_SS2"

#define NVS_PW2_USERNAME     "USERNAME_PW2"
#define NVS_PW2_DATETIME   "DATETIME_PW2"

#define NVS_INH_USERNAME     "USERNAME_INH"
#define NVS_INH_DATETIME   "DATETIME_INH"

#define NVS_SP_USERNAME     "USERNAME_SP"
#define NVS_SP_DATETIME   "DATETIME_SP"

#define NVS_ERASE_USERNAME     "USERNAME_ERASE"
#define NVS_ERASE_DATETIME   "DATETIME_ERASE"

#define NVS_PT_USERNAME     "USERNAME_PT"
#define NVS_PT_DATETIME   "DATETIME_PT"

#define NVS_ERASED_SERIAL_NUMBER   "ERASED_SERIAL_NUMBER"

#define NVS_SERIAL_NUMBER   "SERIAL_NUMBER"

#define NVS_LAST_TID   "LAST_TID"

#define NVS_PASS_THRU   "Y"

#define NVS_SIP_NUMBER   "SIP_NUMBER"
  // added on 100525
#define NVS_MIP_NUMBER   "MIP_NUMBER"

#define NVS_MQTT_PASS   "MQTT_PASS"
#define NVS_MQTT_USER   "MQTT_USER"

#define NVS_MQTT_PASS1   "MQTT_PASS1"
#define NVS_MQTT_USER1   "MQTT_USER1"

#define NVS_MQTT_PASS2   "MQTT_PASS2"
#define NVS_MQTT_USER2   "MQTT_USER2"

#define NVS_MQTT_PASS3   "MQTT_PASS3"
#define NVS_MQTT_USER3   "MQTT_USER3"


#define HBT_TIMEOUT_SEC 120

#define NVS_CUR_TIME  "CUR_TIME"
#define NVS_DISCON_DTIME  "DSICON_DTIME"
#define NVS_RICON_DTIME  "RICON_DTIME"

#define NVS_WIFI_DISCON_DTIME "WIFI_DISCON_DTIME"
#define NVS_MQTT_DISCON_DTIME "WIFI_DISCON_DTIME"
#define NVS_TCP_DISCON_DTIME "WIFI_DISCON_DTIME"

#define NVS_LIGHT_TIME "LIGHT_TIME"
#define NVS_PLAY_TIME "PLAY_TIME"
#define NVS_GAP_TIME "GAP_TIME"
#define NVS_TOTAL_LIGHTS "TOTAL_LIGHTS"

//# define HBTTIMEBEFORERESTART 21000
# define HBTTIMEBEFORERESTART 900 // seconds
# define DeviceHBTTime 300000 // msec

// #define DEFAULT_SERVER_IP_ADDR_TRY "gvc.co.in"
// #define DEFAULT_SERVER_IP_ADDR "159.89.248.57"
#define DEFAULT_SERVER_PORT    6666
//#define DEFAULT_FOTA_URL  "http://gvc.co.in/esp/esp_wifi_tcp_fota.bin"
#define DEFAULT_FOTA_URL  "http://test-firmware.kwikpay.uk/firmware/fw070125_118.bin"
//#define TCP_URL1  "gvc.co.in"
#define TCP_URL1  "GVCTCP.KWIKPAY.COM"
#define TCP_URL2  "GVCTCP.KWIKPAY.COM"
#define TCP_URL3  "GVCTCP.KWIKPAY.COM"
#define TCP_PORT1   6666
#define TCP_PORT2   6666
#define TCP_PORT3   6666

// added on 090525
#define MQTT_BROKER1  "mqtt://snackboss-iot.in:1883"
#define MQTT_BROKER2  "mqtt://snackboss-iot.in:1883"
#define MQTT_BROKER3  "mqtt://snackboss-iot.in:1883"

#define MQTT_USER1  "gvcMqttServer"
#define MQTT_USER2  "gvcMqttServer"
#define MQTT_USER3  "gvcMqttServer"

#define MQTT_PASS1  ""
#define MQTT_PASS2  ""
#define MQTT_PASS3  ""

#define PASS_THRU   "Y"

#define FWVersion "*KP-WAM - 210725 #"



#define HBTDelay    300000
#define LEDR    13
#define LEDG    12

#define JUMPERX  15
#define JUMPER2  18


#define RxD2    16
#define ErasePin 0
#define ICH1    33
#define ICH2    32
#define ICH3    35
#define ICH4    34
#define ICH5    26
#define ICH6    27
#define ICH7    25
#define INH     23

#define STRB    19
#define CLK     22
#define DAT    21
#define STRB1  15
#define STRB2  15
#define STRB3  15
#define STRB4  15

#define CINHO   14
#define CINHI   23

#define L1      5   //2
#define L2      4 //5
#define L3      2 //4
#define LedHBT  L1
#define LedTCP  L2
#define LEDBUZZER  3

#define SDA     21
#define SCL     22

#define MKM_IC_UART UART_NUM_2
#define MKM_IC_UART_TX 17
#define MKM_IC_UART_RX 16
#define INHIBITLevel 1


#define DATE_TIME "120425142359"


#define EX_UART_NUM UART_NUM_2
#define BUF_SIZE (1024)
#define RD_BUF_SIZE (BUF_SIZE)


#if CONFIG_ESP_WIFI_AUTH_OPEN
#define ESP_WIFI_SCAN_AUTH_MODE_THRESHOLD WIFI_AUTH_OPEN
#elif CONFIG_ESP_WIFI_AUTH_WEP
#define ESP_WIFI_SCAN_AUTH_MODE_THRESHOLD WIFI_AUTH_WEP
#elif CONFIG_ESP_WIFI_AUTH_WPA_PSK
#define ESP_WIFI_SCAN_AUTH_MODE_THRESHOLD WIFI_AUTH_WPA_PSK
#elif CONFIG_ESP_WIFI_AUTH_WPA2_PSK
#define ESP_WIFI_SCAN_AUTH_MODE_THRESHOLD WIFI_AUTH_WPA2_PSK
#elif CONFIG_ESP_WIFI_AUTH_WPA_WPA2_PSK
#define ESP_WIFI_SCAN_AUTH_MODE_THRESHOLD WIFI_AUTH_WPA_WPA2_PSK
#elif CONFIG_ESP_WIFI_AUTH_WPA3_PSK
#define ESP_WIFI_SCAN_AUTH_MODE_THRESHOLD WIFI_AUTH_WPA3_PSK
#elif CONFIG_ESP_WIFI_AUTH_WPA2_WPA3_PSK
#define ESP_WIFI_SCAN_AUTH_MODE_THRESHOLD WIFI_AUTH_WPA2_WPA3_PSK
#elif CONFIG_ESP_WIFI_AUTH_WAPI_PSK
#define ESP_WIFI_SCAN_AUTH_MODE_THRESHOLD WIFI_AUTH_WAPI_PSK
#endif

