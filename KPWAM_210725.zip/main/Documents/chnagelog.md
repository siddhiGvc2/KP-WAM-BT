## 1.22I - 010525
## Modify
- All MQTT commands to have user name and time stamp similar to TCP commands
#3 020525
-- send TC command when coin inserted / hardware.c
-- created a new function SendTCResponse / mqtt.c
-- created new variable TCPRequired, Send response only if TCPRequired is set / vars. externvars, calls
-- create one more sub topic as GVC/KP/BROADCAST mqtt.c
-- if HBT-OK not received in X minutes and wifi is okay and MQTT is connected the reset the device
-- HBT-D is the command from device and HBT-S is the command from server
-- Pulse wisth is between 20 and 250 msec / hardware.c

#4 030525
-- stack for publish_mqtt task increased from 5k to 8k
#5 050525
-- do not reply when *HBT-S# is received / command.c
-- QOS option added on Subscribe
-- compare topic with broadcast as well serial number to allow action
-- ??? some times data not being senses by MQTT
-- ??? on 3rd May 2:52:00 pm one pulse missed while generating or receiving
-- blink leds when MQTT received moved 3 lines from analysePacketTcp.c to command.c

## 1.23- 090525
#1 090525
-- Add setting for MQTT_BROKER1, MQTT_BROKER2, MQTT_BROKER3. changed in /main/inc/defs
-- Change mqtt server as per *SIP:x# changed in /main/src/SaveRecallNVS.c
-- *MQTT:user:password# command added & saved in memory  changed in /main/src/commands.c
-- sent TC-D at sendTCresponse  changed in /main/src/mqttRoutine.c
-- *MQTT?# command added changed in /main/src/commands/c
--- & saved MQTT default user & pASSWORD values in memory. changed in/main/src/SaveRecallNvs.c
-- remove comparison of topic with expected topic  case MQTT_EVENT_DATA:/mqttRoutines.c
-- when INH input changes, send TCP/MQTT/UARt

## 1.23 - 100525
-- write code to get free heap and free internal heap
-- get that value on command *HEAP?# /main/src/analysePacketUart.c
-- send value to MQTT and TCP and UART 
-- removed retyrMqtt task . /main/main.c
-- enabled auto reconnect in mqtt configuration. //.network.disable_auto_reconnect = false,
-- *MIP:MipUsername:MipDateTime:MipNumber# command added in commands.c
-- & recalled from SaveRecallNVS.c
-- *MIP? command added in commands.c

## 1.23A - 290525
-- *TESTON# will start self test. Send pulse once per second and MQTT when all seven pulses match with input
-- change TESTCOIN and gpio_read_n_act
-- get RSSI info every 15 seocnds if wifi connected
-- *RSSI?# reply with *RSSI,value);


## 1.23 C - 130625
-- UartDebugInfo variannble added to disable Uart Logs.
-- Only QR:, STATUS? commands enabled on uart.

## KP-WAM  010725
-- *LTime:LightTime# 
-- *PTime:PlayTime#
-- *NL:NumberOfLights#
commands added.

## KP-WAM
-- at power on randomly switch on lights for Light Time
-- Start when power on (will add start switch later)
-- switch on random light for LTime

## 020725
-- add code in task and not in for loop as this waits for WiFi
-- light on time is as per setting
-- sense switch (if pressed when light is on - This is success, if wrong pressed - error 1, if not prrssed - error 2)

-- Blink Time = LightTime * 100, do this at NVS recall and when setting

-- remove switch press width
-- increment count

-- set all three error count = 0 at power on
-- send error coyunt to MQTT/TCP as *LedErrCount:OKCount:WrongCount:NoCount# when command is *LedErrCoun?#

-- set time gap between lights 
-- start when any switch is pressed
-- stop when three missed counts

## 030725
-- GapBeforeNextTime SET/RECALL added

## 040725

-- New format added *Status,START# and *Status,STOP#
-- new format to be added
*Status,x,y,ok,notok,missed#
change to *Status,x,y,ok,notokay,missed,time,avgtime#
time is in x.y Secs 4.3 Secs

-- change number of lights to 7
-- and shift them to output now

## 050725
-- started at 11:30
-- sense switch. if sensed, switch off light - done 11:52
-- and not time period in 100s mssec ie 1 second as 10 - done at 12:20 PM
-- stop game if key not pressed for some value (GTime as it is already set)
-- stop game after playtime is over
-- display remaining time
-- whem game over display result
-- no sensing for 30 seconds

## 060725
-- blink result when game over.
-- blink starting count down timer
-- add leading zero blanking
-- display total okay and avaerga time for switch pressed
-- add buzzer , Buzzer time is set by LTime and saved as BlinkLedTime  = 10 * LTime

## 210725
-- add #START# COMMAND






